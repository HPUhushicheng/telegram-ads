# 运行

双击 run_telegram.bat 即可

注意当前网络环境，是否可以正常连接到 tg 服务器，可以使用 test_lianjie_tg.bat 测试,双击

如果出现请求超时无法连接或运行失败，再联系我
